﻿var StudentOperation_ENUM;
(function (StudentOperation_ENUM) {
    StudentOperation_ENUM[StudentOperation_ENUM["Save_Student_Data"] = 0] = "Save_Student_Data";
    StudentOperation_ENUM[StudentOperation_ENUM["Edit_Student_Data"] = 1] = "Edit_Student_Data";
})(StudentOperation_ENUM || (StudentOperation_ENUM = {}));