﻿//const WEB_API_URL_Student = "http://localhost:55830/api/StudentName";

//const WEB_API_URL_Student = "http://ltpe4.web.techcollege.dk/api/StudentName";

const WEB_API_URL_Student = "http://webapisimple.buchwaldshave34.dk/api/StudentName";
